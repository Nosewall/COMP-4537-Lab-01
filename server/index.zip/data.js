json_cities = {
    "list": [
        {
            "name": "Vancouver",
            "tempreture": 25.5,
            "description": "hot"
        },
        {
            "name": "Tokyo",
            "tempreture": 39.5,
            "description": "scorching"
        },
        {
            "name": "Paris",
            "tempreture": "19",
            "description": "cloudy"
        }
    ]
}

module.exports = json_cities